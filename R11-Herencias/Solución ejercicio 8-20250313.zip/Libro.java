public class Libro extends Publicacion implements Prestable {
    // Atributos
    private boolean prestado;

    // Constructor con parámetros
    public Libro(String ISBN, String titulo, int anio) {
        super(ISBN, titulo, anio);
        this.prestado = false;
    }

    // Métodos
    @Override
    public String toString() {
        return super.toString() + "(" + (this.prestado ? "prestado" : "no prestado") + ")";
    }

    // Métodos de la interfaz Prestable
    public void presta() {
        if (this.prestado) {
            System.out.println("Ese libro ya está prestado.");
        }
        else this.prestado = true;
    }

    public void devuelve() {
        this.prestado = false;
    }

    public boolean estaPrestado() {
        return this.prestado;
    }

}
