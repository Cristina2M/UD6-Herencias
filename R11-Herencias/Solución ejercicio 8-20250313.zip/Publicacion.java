public abstract class Publicacion {

    // Atributos
    protected String titulo;
    protected int anio;
    protected String ISBN;

    // Constructor con parámetros
    public Publicacion(String ISBN, String titulo, int anio ) {
        this.titulo = titulo;
        this.anio = anio;
        this.ISBN = ISBN;
    }

    // Métodos
    @Override
    public String toString() {
        return "ISBN: " + ISBN + ", Título: " + titulo + ", Año de publicación: " + anio;
    }
}