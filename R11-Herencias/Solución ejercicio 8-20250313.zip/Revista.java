public class Revista extends Publicacion {
    // Atributos
    private int numero;

    // Constructor con parámetros
    public Revista(String ISBN, String titulo, int anio, int numero) {
        super(ISBN, titulo, anio);
        this.numero = numero;
    }

    // Métodos
    @Override
    public String toString() {
        return super.toString();
    }
    
}
